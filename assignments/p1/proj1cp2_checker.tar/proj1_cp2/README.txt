Steps
=====
- Extract this test folder inside the folder having lisod executable
- Extract static files (provided) and rename the folder as www
- Place the www folder in same folder as lisod executable
- Start your lisod server
- Execute the cmd "./graderpj1cp2.py <ip> <port>"
